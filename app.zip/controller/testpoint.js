
const test= (req,res)=>{
     res.status(200).json({message:"Works fine"})
}
module.exports= test
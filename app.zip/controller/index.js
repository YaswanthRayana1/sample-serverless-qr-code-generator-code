const signup = require("./signup.js")
const login = require("./login.js")
const qrCodeHandeler = require("./qr-code-handeler.js")
const testing = require("./testpoint.js")
module.exports={signup,login,qrCodeHandeler, testing}